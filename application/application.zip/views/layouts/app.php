<?php 
require_once 'header.php';
require_once 'sidebar.php';
require_once 'nav.php';
$this->load->view($content);
require_once 'footer.php';